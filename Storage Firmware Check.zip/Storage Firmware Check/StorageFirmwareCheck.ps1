﻿<#
.SYNOPSIS
HP_Storage_Firmware_Check.ps1 - Script that checks firmware for HP storage array disks

.DESCRIPTION 
Generates a report file or an email telling if disks installed in HP MSA have newest firmware

All the configuration files should be placed in $JSON_Files_Location location.

.OUTPUTS
Verbose option
Report file - HTML
Report email

.PARAMETER file
Generates a report for all mailboxes on the specified server.

.PARAMETER filepath
Generates a report for all mailboxes on the specified database.

.PARAMETER email
Generates a report for mailbox names listed in the specified text file.

.PARAMETER verbose
Generates a report only for the specified mailbox.

.EXAMPLE
.\StorageFirmwareCheck.ps1 -File -Email -Verbose
That command will generate a HTML file in the default location ".\", will email the report and show all verbose information so information about the performed actions

.EXAMPLE
.\StorageFirmwareCheck.ps1 -File -FilePath "C:\ReportFolder\"
That command will generate a HTML file in the "C:\ReportFolder\" folder

.EXAMPLE
.\StorageFirmwareCheck.ps1 -Email
That command will generate a report email

.LINK
https://paweljarosz.wordpress.com/2016/11/03/hp-msa-powershell-script-to-check-if-disk-drives-firmware-revision-is-up-to-date

.NOTES
Written By: Pawel Jarosz
Website:	http://paweljarosz.wordpress.com
GitHub:     https://github.com/zaicnupagadi
Technet:    https://gallery.technet.microsoft.com/scriptcenter/site/mydashboard


Change Log
V1.00, 03/11/2016 - Initial version

#>


Param(
  [switch]$File,
  [string]$FilePath,
  [switch]$Email,
  [switch]$verbose
)

if (!$FilePath){
$FilePath = ".\"
}

if ($File){
$FileARG = "True"
}

if ($Email){
$EmailARG = "True"
}

 if($verbose) {

   $oldverbose = $VerbosePreference

   $VerbosePreference = "continue" }

Function Check_Storage_Array_Firmware([string]$FileARG, [string]$FilePath, [string]$EmailARG) {

$JSON_Files_Location = "C:\<Example Folder>\Storage Firmware Check\JsonConfig\"

$Header = "
<html>
<header>
<style>
TABLE {border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}
TH {border-width: 1px;padding: 3px;border-style: solid;border-color: black;background-color: #6495ED;}
TD {border-width: 1px;padding: 3px;border-style: solid;border-color: black;}
td.green {border-width: 1px;padding: 3px;border-style: solid;border-color: black;background-color: #c2f0c2;}
td.greener {border-width: 1px;padding: 3px;border-style: solid;border-color: black;background-color: #33cc33;}
td.red {border-width: 1px;padding: 3px;border-style: solid;border-color: black;background-color: #ff3300;}
.borderless td {border-top-style: none;border-left-style: none;border-right-style: none;border-bottom-style: none;}
</style>
</header>
"
 
$body = "<body>"

$report = @()
$uri = "h20628.www2.hp.com/km-ext/content-webapp/document?docId=emr_na-c04315770"
$html = Invoke-WebRequest $uri

$HP_Web_Page_Parsed = ($html.ParsedHtml.getElementsByTagName("tr") <#| where {$_.innerhtml -match "EG0900FCSPN"}#> | select -ExpandProperty innerhtml)

$HP_Web_Page = $HP_Web_Page_Parsed.replace('<TD>','').replace('</DIV>','').replace('</TD>','').replace('<DIV class=ods_si_para>',';').replace("`n","").Substring(2)

ForEach ($Web_Element in $HP_Web_Page){

$Element_Properties = $Web_Element -split ";"

$DiskObj = New-Object PSObject
$DiskObj | Add-Member NoteProperty -Name "HPModelNumber" -Value $Element_Properties[0]
$DiskObj | Add-Member NoteProperty -Name "BareDriveAssemblyNumber" -Value $Element_Properties[1]
$DiskObj | Add-Member NoteProperty -Name "CurrentFWFileVersion" -Value $Element_Properties[2]
$DiskObj | Add-Member NoteProperty -Name "OptionPartNumber" -Value $Element_Properties[3]
$DiskObj | Add-Member NoteProperty -Name "SparePartNumber" -Value $Element_Properties[4]
$DiskObj | Add-Member NoteProperty -Name "SpareKitDescription" -Value $Element_Properties[5]
$DiskObj | Add-Member NoteProperty -Name "RoHSCompliant" -Value $Element_Properties[6]

$report = $report += $DiskObj
}

$All_Json_Config_Files = (Get-ChildItem "$JSON_Files_Location")

ForEach ($Json_File in $All_Json_Config_Files){
$Json_Files = @()
$Json_Files = Get-Content -Raw -Path $Json_File.FullName | ConvertFrom-Json
$Array_Name = $Json_Files.Storage_Array_Name
#$b.Controller_Firmware_Version
$body += "<table><tr><th colspan='4'><p>$Array_Name</p></th></tr>"

ForEach ($Controller in $Json_Files.Controller_Firmware_Version) {
$crevision = $Controller.revision
$link =  $Controller.verifylink
$contVer = $Controller.controller

$body += "<tr><td colspan='2'><p>Controller $contVer Firmware Revision</p></td><td colspan='2'><p>$crevision <a href=$link>VerifyRevisionHere</a></p></td></tr>"
}

$body += "<tr><td><p>Slot Number</p></td><td><p>Disk Model</p></td><td><p>Firmware revision</p></td><td><p>Additional info</p></td></tr>"

ForEach ($Json_Attribute in $Json_Files.Disk_Drives_Firmware_Version) {

$SimilarDrives = @()
    ForEach ($element in $report){

        if ($element.HPModelNumber -match $Json_Attribute.DiskDriveModel){
        $elem = $element.CurrentFWFileVersion.trim()
        $SimilarDrives += $elem
        }

    }
$RevisionsAcrossSimilarDrives = ($SimilarDrives | Select -Unique).Count
$Firmwares = [string]::Join(", ",$SimilarDrives)
if (($SimilarDrives -contains $Json_Attribute.Revision -and $SimilarDrives.Length -gt 1 -and $RevisionsAcrossSimilarDrives -lt "2") -or ($SimilarDrives -contains $Json_Attribute.Revision -and $SimilarDrives.Length -eq 1 -and $RevisionsAcrossSimilarDrives -eq "1") ) {
$TdColour = "greener"
}
elseif ($SimilarDrives -contains $Json_Attribute.Revision -and $RevisionsAcrossSimilarDrives -gt "1"){
$Firmwares = [string]::Join(", ",$SimilarDrives)
$TdColour = "green"
$Info = "More than one available revision: $Firmwares"
} else {
$TdColour = "red"
$Info = "Proper revision is one of following: $Firmwares"
}
$slot = $Json_Attribute.Slot
$DiskModel = $Json_Attribute.DiskDriveModel
$revision = $Json_Attribute.Revision

$body += "
<tr><td><p>$slot</p></td><td><p>$DiskModel</p></td><td class=$TdColour><p>$Revision</p></td><td><p>$Info</p></td></tr>
"

$SimilarDrives.clear()
$info = ""
}
$body += "
</table></br>
"
}

$footer = "
</body>
</html>
"

$EmailBody = "$header $body $footer"

if ($FileARG -eq "True"){
$EmailBody | Out-File "$FilePath\Storage_Array_Firmware_Checkout.html"
Write-Verbose "File has been saved to $FilePath\Storage_Array_Firmware_Checkout.html"
}

if ($EmailARG -eq "True") {
$EmailSubject = "Storage Array Disk Report"
$EmailRcpt  = "TestRecipient@domain.com"
$EmailFrom = "test@automation.com"
$EmailServer = "smtp.server.com"
Send-MailMessage -From "$EmailFrom" -To "$EmailRcpt" -Subject "$EmailSubject" -Body "$EmailBody" -SmtpServer "$EmailServer" -BodyAsHtml
Write-Verbose "Email with subject '$EmailSubject' has been sent out to following recipients: "
}


}

Check_Storage_Array_Firmware "$FileARG" "$FilePath" "$EmailARG"